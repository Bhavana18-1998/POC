package com.thbs.poc.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.thbs.poc.entity.UsersEntity;
import com.thbs.poc.exception.UserNotFoundException;
import com.thbs.poc.payload.request.LoginResetRequest;
import com.thbs.poc.payload.response.ForgotResponse;
import com.thbs.poc.payload.response.Responses;
import com.thbs.poc.repository.UserRepository;
import com.thbs.poc.security.HashPassword;

@Service
public class LoginResetService {

   @Autowired
   private UserRepository repository;
   
   @Autowired
   private HashPassword hashPassword;

 //Service for Login
    public Responses signIn( LoginResetRequest loginRequest) {
    	
    	//String password=hashpassword.passwordEncrytion(loginRequest.getPassword());
    	 String password=hashPassword.passwordEncrytion(loginRequest.getPassword());
		Optional<UsersEntity> users = repository.findByEmailAndPassword(loginRequest.getEmail(),password);
		System.out.println("hoii");
		if (!users.isPresent()) {
			throw new UserNotFoundException("User is not Registered");
		}
	
		 return methodResponse(users.get());
    }
    
//forgotPassword service

   	public ForgotResponse forgotPassword(String email) {
   		
   		ForgotResponse forgotResponse=new ForgotResponse();
   		Optional<UsersEntity> user=repository.findByEmail(email);
   		System.out.println("the error");
   		if (!user.isPresent()) {
   			System.out.println("not proper");
   			throw new UserNotFoundException("Email is not Registered");
   		}
   		System.out.println("success");
   		forgotResponse.setMessage("Email Validated! Reset your password here");
   		forgotResponse.setCode(200);
   		
             return forgotResponse;
   	}
   	
   	
//ResetPassword Service
   	
   	public Responses resetPassword(LoginResetRequest resetRequest) {
    	UsersEntity user=new UsersEntity();
    	
        if (!repository.findByEmail(resetRequest.getEmail()).isPresent()) {
        	System.out.println("reached backend reset");
        	throw new UserNotFoundException("Email is not Registered");
           }
        
        Optional<UsersEntity> userEntity= repository.findByEmail(resetRequest.getEmail());
        
        user.setEmail(resetRequest.getEmail());
        user.setPassword(hashPassword.passwordEncrytion(resetRequest.getPassword()));
	    System.out.println("my encryted password   "+user.getPassword());
        user.setUsersid(userEntity.get().getUsersid());
        user.setFullname(userEntity.get().getFullname());
        user.setMobilenumber(userEntity.get().getMobilenumber());
        user.setUsername(userEntity.get().getUsername());

        UsersEntity users= repository.save(user);
        
        return methodResponse(users);
}
   	
//Responses Method
   	
        private Responses methodResponse(UsersEntity users) {
   		
   		   Responses resetResponse=new Responses();
   		   resetResponse.setCode(200);
   		   resetResponse.setMessage("Successfull");
   	  	   resetResponse.setEmail(users.getEmail());
   		   resetResponse.setFullname(users.getUsername());
   		   resetResponse.setMobilenumber(users.getMobilenumber());
   	       resetResponse.setUsersid(users.getUsersid());
   	       resetResponse.setUsername(users.getUsername());
   		
   		   return resetResponse;
   	
   	}
        
  
}
   	
    


   	
   	
   	
   	
   	
   	
   	
   	
   	
   	
   	
   	
   	
   	
   	
   	
   	
  

    
    

   
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
