package com.thbs.poc.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.thbs.poc.entity.UsersEntity;

@Repository
public interface UserRepository extends JpaRepository<UsersEntity, Integer> {

	Optional<UsersEntity> findByEmailAndPassword(String email, String password);

	Optional<UsersEntity> findByEmail(String email);

	

}
