package com.thbs.poc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.thbs.poc.payload.request.LoginResetRequest;
import com.thbs.poc.payload.response.ForgotResponse;
import com.thbs.poc.payload.response.Responses;
import com.thbs.poc.service.LoginResetService;
@CrossOrigin()
@RestController
public class LoginResetController {
	
	@Autowired
    private LoginResetService loginResetService;


	//Login With Email and Password

    @RequestMapping(value = "/login",method = RequestMethod.POST)
	public ResponseEntity<Responses> signIn( @RequestBody LoginResetRequest loginResetRequest) {
    	Responses user = loginResetService.signIn(loginResetRequest);
        return ResponseEntity.status(HttpStatus.OK).body(user);
      }
    
//Forgot Password Using Email
    
    @RequestMapping(value="/forgot",method=RequestMethod.POST)
    public ResponseEntity<ForgotResponse> findByEmail(@RequestBody LoginResetRequest resetRequest){
    	
    	ForgotResponse user=  loginResetService.forgotPassword(resetRequest.getEmail());
    	
    		return  ResponseEntity.status(HttpStatus.OK).body(user);
    }
 // User ResetPassword 
    
    @RequestMapping( value = "/reset",method = RequestMethod.PUT)
    public ResponseEntity<Responses> resetPassword(@RequestBody LoginResetRequest resetRequest) {
        Responses user = loginResetService.resetPassword(resetRequest);
        return ResponseEntity.status(HttpStatus.OK).body(user);
       }

}
    

    
    
    
    
    
    
