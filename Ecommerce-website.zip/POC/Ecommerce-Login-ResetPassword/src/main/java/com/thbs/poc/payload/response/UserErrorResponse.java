package com.thbs.poc.payload.response;

public class UserErrorResponse {
  
	private int status;
	private String message;
	
	
	public UserErrorResponse()
	{
		
	}
	
	public UserErrorResponse(int status, String message) {
		
		this.status = status;
		this.message = message;
		
	}
	
	//Getters and Setters
	
	public void setStatus(int status) {
		this.status = status;
	}
	public int getStatus() {
		return status;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
}
