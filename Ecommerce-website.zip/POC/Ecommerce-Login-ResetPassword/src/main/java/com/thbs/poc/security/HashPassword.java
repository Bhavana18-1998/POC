package com.thbs.poc.security;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.stereotype.Component;

@Component
public class HashPassword {

	
	public  String hashPassword(String password) throws NoSuchAlgorithmException
	{
    MessageDigest messageDigest=MessageDigest.getInstance("MD5");
	messageDigest.update(password.getBytes());
	byte[] byteName=messageDigest.digest();
	StringBuffer stringBuffer=new StringBuffer();
	for(byte byteVar:byteName) {
		stringBuffer.append(Integer.toHexString(byteVar & 0xff).toString());
		
	}
	System.out.println(stringBuffer.toString());
	return stringBuffer.toString();
	
}


	public  String  passwordEncrytion(String password)
	{
		String encryted="encryt";

		try {
			encryted= hashPassword(password);
		} catch (NoSuchAlgorithmException e) {
			
			e.printStackTrace();
		}
		return encryted;
	
	}
	
}
