package com.thbs.poc.service;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.thbs.poc.model.RegisterModel;
import com.thbs.poc.register.RegisterEntity;
import com.thbs.poc.repository.RegisterRepository;
import com.thbs.poc.response.CommonResponse;
import com.thbs.poc.security.HashPassword;

@Service
public class RegisterationService 
 {
    @Autowired
    RegisterRepository repository;
	
    @Autowired
    HashPassword hashPassword;
    
	public RegisterModel saveUserDetails(RegisterModel registerModel)
	{   
		RegisterEntity registerEntity = new RegisterEntity();
		
    	RegisterModel response = new RegisterModel();
    	
    	
	    registerEntity.setFullName(registerModel.getFullName());
	    registerEntity.setUsername(registerModel.getUserName());
	    registerEntity.setMobileNumber(registerModel.getMobileNumber());
	    registerEntity.setEmail(registerModel.getEmail());
	    registerEntity.setPassword(hashPassword.passwordEncrytion(registerModel.getPassword()));
	    System.out.println("my encryted password   "+registerEntity.getPassword());
        RegisterEntity saveUserDetails=repository.save(registerEntity);
        response.setFullName(saveUserDetails.getFullname()); 
        response.setUserName(saveUserDetails.getUserName());
        response.setMobileNumber(saveUserDetails.getMobileNumber());
        response.setEmail(saveUserDetails.getEmail());
        response.setPassword(saveUserDetails.getPassword());
         
	    return response; 
	}
	  
	public CommonResponse checkEmailNotTaken(String email)
    {   
		CommonResponse response = new CommonResponse();
		
		Optional<RegisterEntity> getUsersDataForEmail =repository.findByEmail(email);
		
	    if(getUsersDataForEmail.isPresent() && getUsersDataForEmail.get().getEmail().equalsIgnoreCase(email)) 
	    {
			 System.out.println("Email already registered");
			 response.setCode(226);
			 response.setResponse("Email is already registered");
	    }	
	  else
	    {
			 System.out.println("Successfully registered");
             response.setCode(200);
             response.setResponse("Successfully registered");
	     }
	    return response;
		}
	
	public CommonResponse checkUserNameNotTaken(String userName)
    {   
		CommonResponse response = new CommonResponse();
		
		Optional<RegisterEntity> getUsersDataForUserName =repository.findByUserName(userName);
		
	    if(getUsersDataForUserName.isPresent() && getUsersDataForUserName.get().getUserName().equalsIgnoreCase(userName)) 
	    {
			 System.out.println("Username already registered");
			 response.setCode(226);
			 response.setResponse("UserName is already registered");
	    }	
	  else
	    {
			 System.out.println("Successfully registered");
             response.setCode(200);
             response.setResponse("Successfully registered");
	     }
	    return response;
		}
   
 }




	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
