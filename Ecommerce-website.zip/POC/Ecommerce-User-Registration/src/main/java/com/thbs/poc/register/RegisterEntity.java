package com.thbs.poc.register;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.springframework.stereotype.Component;

import com.sun.istack.NotNull;

  @Entity
  @Component
  @Table(name="users")
  public class RegisterEntity {
	
  @GeneratedValue(strategy=GenerationType.IDENTITY)
  @Id
  @NotNull
  @Min(0)
  @Max(9999)
  @Column(name = "users_id")
  private int usersid;
	
	
  @NotNull
  @Size(min = 4, max = 25, message = "Name should be 4-15 characters")
  @Pattern(regexp = "^[a-zA-Z]+ [a-zA-Z]+$", message = "Only Alphabets are allowed")
  @Column(name = "full_name")
  private String fullName;
	
  @NotNull
  @Size(min=3,max=25,message="user name is not valid")
  @Column(name = "user_name")
  private String userName;
	
  @NotNull
  @Pattern(regexp="^[6789][0-9]{9}$", message = "Only Numbers are allowed")
  @Column(name = "mobile_number")
  private String mobileNumber;
	
  @Email(message = "Enter a valid email address.")
  @Column(name = "email_id")
  private String email;
	
  @NotNull
  @Column(unique=true) 
//  @Pattern(",message="password is not valid")
  private String password;
	
  public RegisterEntity() 
  {
		super();
  }

   public RegisterEntity(int usersid, String fullName, String userName, String mobileNumber, String email,
   String password) 
   {
		super();
		this.usersid = usersid;
		this.fullName = fullName;
		this.userName = userName;
		this.mobileNumber = mobileNumber;
		this.email = email;
		this.password = password;
	}

	public int getUsersid()
	{
		return usersid;
	}

	public void setUsersid(int usersid)
	{
		this.usersid = usersid;
	}

	public String getFullname() 
	{
		return fullName;
	}

	public void setFullName(String fullName) 
	{
		this.fullName = fullName;
	}

	public String getUserName() 
	{
		return userName;
	}

	public void setUsername(String userName) 
	{
		this.userName = userName;
	}

	public String getMobileNumber() 
	{
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber)
	{
		this.mobileNumber = mobileNumber;
	}

	public String getEmail() 
	{
		return email;
	}

	public void setEmail(String email) 
	{
		this.email = email;
	}

	public String getPassword()
	{
		return password;
	}

	public void setPassword(String password)
	{
		this.password = password;
	}

	@Override
	public String toString() {
	return "RegisterEntity [usersid=" + usersid + ", fullName=" + fullName + ", userName=" + userName
		+ ", mobilenumber=" + mobileNumber + ", email=" + email + ", password=" + password + "]";
	}
}



	