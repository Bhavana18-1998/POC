package com.thbs.poc.repository;
import java.util.Optional;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.thbs.poc.register.RegisterEntity;


@Repository
public interface RegisterRepository extends  JpaRepository <RegisterEntity,Integer>
 {
    Optional<RegisterEntity> findByEmail(String email);
    
	Optional<RegisterEntity> findByUserName(String userName);
 }



