package com.thbs.poc.response;

public class CommonResponse 
 {

	private int code;
	private String response;
	
	public CommonResponse() 
	{
		super();
	}
	
	public CommonResponse(int code, String response) 
	{
		super();
		this.code = code;
		this.response = response;
	}
	

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}
	
 }
