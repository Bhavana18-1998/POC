package com.thbs.poc.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.thbs.poc.model.RegisterModel;
import com.thbs.poc.response.CommonResponse;
import com.thbs.poc.service.RegisterationService;

@CrossOrigin
@RestController
public class RegisterController 
  {

	@Autowired
    RegisterationService service;
	
	@RequestMapping(value= "/register",method=RequestMethod.POST)
    public ResponseEntity<RegisterModel> saveUserDetails(@RequestBody RegisterModel register) 
    {
	RegisterModel response = service.saveUserDetails(register);    
    return ResponseEntity.status(HttpStatus.OK).body(response);
    }
	
	@RequestMapping(value="/userByEmail/{email}",method=RequestMethod.GET)
	public ResponseEntity<CommonResponse> checkEmailNotTaken(@PathVariable("email") String email )
	{
	CommonResponse response = service.checkEmailNotTaken(email);
    return ResponseEntity.status(HttpStatus.OK).body(response);
	} 
	
	@RequestMapping(value="/userByUserName/{username}",method=RequestMethod.GET)
	public ResponseEntity<CommonResponse> checkUserNameNotTaken(@PathVariable("username") String username )
	{
	CommonResponse response = service.checkUserNameNotTaken(username);
    return ResponseEntity.status(HttpStatus.OK).body(response);
	} 
} 	
	


	
	
	
	
	
	
	
	
